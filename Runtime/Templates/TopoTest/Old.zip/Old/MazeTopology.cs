using System.Collections.Generic;
using UnityEngine;
//unidirectional connection.  Reverse path is a separate edge, if one even exists.
// when generating a maze using the topology, an edge should be considered a hole in the wall between nodes.  Meaning: the border between two tiles, in different nodes, with the wall removed.
//  exception being teleport edges- these don't depend-on/affect walls at all.
public class MazeEdge
{
    public MazeNode nodeA;
    public MazeNode nodeB;
    public bool isTeleport;
    public MazeEdge(MazeNode nodeA, MazeNode nodeB, bool isTeleport = false)
    {
        this.nodeA = nodeA;
        this.nodeB = nodeB;
        this.isTeleport = isTeleport;
    }
}

//defines a "room" in the maze: each room has at least inbound and/or outbound connection 
//The order or these connections/junctions are stored in the edgeSeunce list contained in this node
// when generating a maze using the topology, a node should be considered a contiguous, single tile width "passage".
public class MazeNode
{
    public string name;
    public bool isMazeStart;
    public bool isMazeEnd;

    // Ordered sequence of in and outbound edge indices (integer index into MazeTopology.mazeEdges)
    // nodeA in all referenced outbound edges, should be THIS node.
    // nodeB in all referenced inbound edges, should be THIS node.
    // The order in the sequnce refers to where on the node's path these edges are, relative to the other edges.
    // when generating a maze using the topology; the first edge should be at the start of the node's passage, the last edge should be at the end of the node's passage.
    public List<int> edgeSequence;

    public MazeNode(string name, bool isMazeStart = false, bool isMazeEnd = false)
    {
        this.name = name;
        this.isMazeStart = isMazeStart;
        this.isMazeEnd = isMazeEnd;
        this.edgeSequence = new List<int>();
    }
}

//defines the general layout of the maze, it's connections and junctions.
//This class can be used to generate a generic maze of any tile-shape/coordinate-type
//When generating a maze using the topology; note that this structure CAN potentially define topologies that are not actually possible in only 2D. Even with teleport edges excepted.
//When this happens, it should throw an exception, with details explaining exactly how the data is invalid.
public partial class MazeTopology
{
    public List<MazeNode> mazeNodes;
    //contains list of all edges in graph, does not need to be orderered
    public List<MazeEdge> mazeEdges;

    public MazeTopology()
    {
        mazeNodes = new List<MazeNode>();
        mazeEdges = new List<MazeEdge>();
    }

    /// Get the actual edge from a node's edge index
    public MazeEdge GetEdge(MazeNode node, int edgeIndex)
    {
        int actualIndex = node.edgeSequence[edgeIndex];
        return mazeEdges[actualIndex];
    }
    public bool IsInbound(MazeNode node, int edgeIndex)
    {
        MazeEdge edge = GetEdge(node, edgeIndex);
        return edge.nodeB == node;
    }
    public List<MazeEdge> GetOutboundEdges(MazeNode node)
    {
        List<MazeEdge> result = new List<MazeEdge>();

        for (int i = 0; i < node.edgeSequence.Count; i++)
        {
            MazeEdge edge = GetEdge(node, i);
            if (edge.nodeB != node)
                result.Add(edge);

        }
        return result;
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="start"></param>
    /// <param name="end"></param>
    /// <returns>returned list excludes start, but includes end.  List is empty if no path exists</returns>
    public List<MazeNode> GetShortestRoute(MazeNode start, MazeNode end)
    {
        if (start == end)
        {
            return new List<MazeNode>();
        }

        Queue<MazeNode> queue = new Queue<MazeNode>();
        Dictionary<MazeNode, MazeNode> cameFrom = new Dictionary<MazeNode, MazeNode>();

        queue.Enqueue(start);
        cameFrom[start] = null;

        while (queue.Count > 0)
        {
            MazeNode current = queue.Dequeue();

            List<MazeEdge> outbound = GetOutboundEdges(current);
            for (int i = 0; i < outbound.Count; i++)
            {
                MazeNode next = outbound[i].nodeB;

                if (cameFrom.ContainsKey(next))
                {
                    continue;
                }

                cameFrom[next] = current;

                if (next == end)
                {
                    List<MazeNode> path = new List<MazeNode>();
                    MazeNode step = end;

                    while (step != start)
                    {
                        path.Add(step);
                        step = cameFrom[step];
                    }

                    path.Reverse();
                    return path;
                }

                queue.Enqueue(next);
            }
        }

        return new List<MazeNode>();
    }

    public Dictionary<int, Vector2> perNodeUV()
    {
        int count = mazeNodes.Count;

        Dictionary<int, Vector2> positionsByNode = new Dictionary<int, Vector2>();
        int[,] numNodeToNodeConnections = new int[count, count];

        // init positions
        for (int i = 0; i < count; i++)
        {
            positionsByNode[i] = Random.insideUnitCircle * 0.5f + Vector2.one * 0.5f;
        }

        // build connection counts (no double counting)
        for (int i = 0; i < count; i++)
        {
            MazeNode node = mazeNodes[i];

            for (int e = 0; e < node.edgeSequence.Count; e++)
            {
                MazeEdge edge = mazeEdges[node.edgeSequence[e]];

                int j = -1;
                if (edge.nodeA == node)
                    j = mazeNodes.IndexOf(edge.nodeB);
                else if (edge.nodeB == node)
                    j = mazeNodes.IndexOf(edge.nodeA);

                if (j >= 0)
                {
                    numNodeToNodeConnections[i, j]++;
                    numNodeToNodeConnections[j, i]++;
                }
            }
        }

        // scale based on node count
        float k = Mathf.Sqrt(1.0f / (float)count);
        float desiredCloseDistance = k;
        float repelStrength = k * k;
        float strengthPer = 0.1f;

        Vector2[] forces = new Vector2[count];

        for (int iter = 0; iter < 500; iter++)
        {
            // reset forces
            for (int i = 0; i < count; i++)
            {
                forces[i] = Vector2.zero;
            }

            // pairwise forces
            for (int i = 0; i < count; i++)
            {
                for (int j = i + 1; j < count; j++)
                {
                    Vector2 posI = positionsByNode[i];
                    Vector2 posJ = positionsByNode[j];

                    Vector2 dir = posI - posJ;
                    float dist = dir.magnitude + 0.0001f;
                    Vector2 norm = dir / dist;

                    int connections = numNodeToNodeConnections[i, j];

                    float force;

                    if (connections > 0)
                    {
                        float restLength = desiredCloseDistance / Mathf.Sqrt((float)connections);
                        force = (dist - restLength);
                    }
                    else
                    {
                        force = -repelStrength / dist;
                    }

                    Vector2 f = norm * force;

                    forces[i] += f;
                    forces[j] -= f;
                }
            }

            // apply + clamp
            for (int i = 0; i < count; i++)
            {
                Vector2 pos = positionsByNode[i];
                pos += forces[i] * strengthPer;

                // keep in [0,1] space
                pos.x = Mathf.Clamp01(pos.x);
                pos.y = Mathf.Clamp01(pos.y);

                positionsByNode[i] = pos;
            }
        }

        return positionsByNode;
    }

    //UV by steps
    public class ForceLayoutState
    {
        public Dictionary<int, Vector2> positionsByNode;
        public HashSet<int> fixedNodes;
        public int[,] connections;
        public int count;

        public float k;
        public float desiredCloseDistance;
        public float repelStrength;
        public float strengthPer;

        public Vector2[] forces;
        public float[] angles;
        public float[] angularForces;
    }


    public ForceLayoutState InitLayout()
    {

        int count = mazeNodes.Count;

        ForceLayoutState state = new ForceLayoutState();
        state.count = count;

        state.positionsByNode = new Dictionary<int, Vector2>();
        state.fixedNodes = new HashSet<int>() { 0, count - 1 };
        state.connections = new int[count, count];
        state.forces = new Vector2[count];
        state.angles = new float[count];
        state.angularForces = new float[count];

        // init positions
        for (int i = 0; i < count; i++)
        {
            state.positionsByNode[i] = Random.insideUnitCircle * 0.5f + Vector2.one * 0.5f;
            state.angles[i] = 0;
            state.angularForces[i] = 0;
        }
        state.positionsByNode[0] = Vector2.zero;
        state.positionsByNode[count - 1] = Vector2.one;

        // build connections (same logic as before)
        for (int i = 0; i < count; i++)
        {
            MazeNode node = mazeNodes[i];

            for (int e = 0; e < node.edgeSequence.Count; e++)
            {
                MazeEdge edge = mazeEdges[node.edgeSequence[e]];
                if (!edge.isTeleport)
                {
                    int j = -1;
                    if (edge.nodeA == node)
                        j = mazeNodes.IndexOf(edge.nodeB);
                    else if (edge.nodeB == node)
                        j = mazeNodes.IndexOf(edge.nodeA);

                    if (j >= 0)
                    {
                        state.connections[i, j]++;
                        state.connections[j, i]++;
                    }
                }
            }
        }

        // scale
        state.k = Mathf.Sqrt(1.0f / (float)count);
        state.desiredCloseDistance = state.k;
        state.repelStrength = 0.3f;// state.k * state.k*0.6f;//
        state.strengthPer = 0.001f;

        return state;
    }


    public void StepLayout(ForceLayoutState state)
    {
        int count = state.count;

        // reset forces
        for (int i = 0; i < count; i++)
        {
            state.forces[i] = Vector2.zero;
            state.angularForces[i] = 0f;
        }

        // pairwise position forces 
        for (int i = 0; i < count; i++)
        {
            for (int j = i + 1; j < count; j++)
            {
                Vector2 posI = state.positionsByNode[i];
                Vector2 posJ = state.positionsByNode[j];

                Vector2 dir = posI - posJ;
                float dist = dir.magnitude + 0.0001f;
                Vector2 norm = dir / dist;

                int connections = state.connections[i, j];

                float force;
                float restLength = state.desiredCloseDistance / Mathf.Sqrt((float)connections + 1);
                float offset = -(dist - restLength);
                force = state.repelStrength * offset;

                Vector2 f = norm * force;

                state.forces[i] += f;
                state.forces[j] -= f;
            }
        }

        // --- rotational forces (edge alignment) ---
        for (int i = 0; i < count; i++)
        {
            MazeNode node = mazeNodes[i];
            int degree = node.edgeSequence.Count;

            if (degree == 0)
                continue;

            float angleStep = Mathf.PI * 2f / degree;

            for (int k = 0; k < degree; k++)
            {
                int edgeIndex = node.edgeSequence[k];
                MazeEdge edge = mazeEdges[edgeIndex];

                MazeNode otherNode = (edge.nodeA == node) ? edge.nodeB : edge.nodeA;
                int j = mazeNodes.IndexOf(otherNode);

                if (j < 0)
                    continue;

                Vector2 posI = state.positionsByNode[i];
                Vector2 posJ = state.positionsByNode[j];

                Vector2 dir = posJ - posI;
                float targetAngle = Mathf.Atan2(dir.y, dir.x);

                float currentAngle = state.angles[i] + k * angleStep;

                float delta = targetAngle - currentAngle;

                // wrap to [-PI, PI]
                while (delta > Mathf.PI) delta -= Mathf.PI * 2f;
                while (delta < -Mathf.PI) delta += Mathf.PI * 2f;

                state.angularForces[i] += delta;
            }
        }
        // --- NEW: edge-edge repulsion ---
        float edgeRepelStrength = state.k * 1f;

        for (int e1 = 0; e1 < mazeEdges.Count; e1++)
        {
            MazeEdge edgeA = mazeEdges[e1];

            int a0 = mazeNodes.IndexOf(edgeA.nodeA);
            int a1 = mazeNodes.IndexOf(edgeA.nodeB);

            Vector2 pA0 = GetEdgeOffset(state, edgeA.nodeA, a0, edgeA, 0.03f) + state.positionsByNode[a0];//GetPortPos(a0, edgeA);
            Vector2 pA1 = GetEdgeOffset(state, edgeA.nodeB, a1, edgeA, 0.03f) + state.positionsByNode[a1];//GetPortPos(a1, edgeA);

            Vector2 midA = (pA0 + pA1) * 0.5f;

            for (int e2 = e1 + 1; e2 < mazeEdges.Count; e2++)
            {
                MazeEdge edgeB = mazeEdges[e2];

                // skip shared nodes (important)
                if (edgeB.nodeA == edgeA.nodeA || edgeB.nodeA == edgeA.nodeB ||
                    edgeB.nodeB == edgeA.nodeA || edgeB.nodeB == edgeA.nodeB)
                    continue;

                int b0 = mazeNodes.IndexOf(edgeB.nodeA);
                int b1 = mazeNodes.IndexOf(edgeB.nodeB);

                Vector2 pB0 = GetEdgeOffset(state, edgeB.nodeA, b0, edgeB, 0.03f) + state.positionsByNode[b0];// GetPortPos(b0, edgeB);
                Vector2 pB1 = GetEdgeOffset(state, edgeB.nodeB, b1, edgeB, 0.03f) + state.positionsByNode[b1];//GetPortPos(b1, edgeB);

                Vector2 midB = (pB0 + pB1) * 0.5f;

                Vector2 d = midA - midB;
                float dist = d.magnitude + 0.0001f;
                Vector2 norm = d / dist;

                float force = edgeRepelStrength / dist;

                Vector2 f = norm * force;

                // apply to endpoints
                state.forces[a0] += f * 0.5f;
                state.forces[a1] += f * 0.5f;

                state.forces[b0] -= f * 0.5f;
                state.forces[b1] -= f * 0.5f;
            }
        }
        // apply translation
        for (int i = 0; i < count; i++)
        {
            if (!state.fixedNodes.Contains(i))
            {
                Vector2 pos = state.positionsByNode[i];
                pos += state.forces[i] * state.strengthPer;

                pos.x = Mathf.Clamp01(pos.x);
                pos.y = Mathf.Clamp01(pos.y);

                state.positionsByNode[i] = pos;
            }
        }

        // --- NEW: apply rotation ---
        float rotationStrength = 0.05f;

        for (int i = 0; i < count; i++)
        {
            if (!state.fixedNodes.Contains(i))
            {
                state.angles[i] += state.angularForces[i] * rotationStrength;
            }
        }

        // --- NEW: angular ordering torque ---
        float angularOrderStrength = 0.3f;

        for (int i = 0; i < count; i++)
        {
            MazeNode node = mazeNodes[i];
            int degree = node.edgeSequence.Count;

            if (degree < 2)
                continue;

            Vector2 center = state.positionsByNode[i];

            // compute actual angles to neighbors
            float[] actualAngles = new float[degree];

            for (int k = 0; k < degree; k++)
            {
                MazeEdge edge = mazeEdges[node.edgeSequence[k]];
                MazeNode other = (edge.nodeA == node) ? edge.nodeB : edge.nodeA;
                int j = mazeNodes.IndexOf(other);

                Vector2 dir = state.positionsByNode[j] - center;
                actualAngles[k] = Mathf.Atan2(dir.y, dir.x);
            }

            // enforce ordering
            for (int k = 0; k < degree; k++)
            {
                int next = (k + 1) % degree;

                float a0 = actualAngles[k];
                float a1 = actualAngles[next];

                float delta = a1 - a0;

                // wrap to [0, 2PI]
                while (delta < 0) delta += Mathf.PI * 2f;
                while (delta > Mathf.PI * 2f) delta -= Mathf.PI * 2f;

                // desired spacing
                float desired = Mathf.PI * 2f / degree;

                float error = delta - desired;

                // push rotation to fix ordering
                state.angularForces[i] += error * angularOrderStrength;
            }
        }
    }
    public void NOTROTStepLayout(ForceLayoutState state)
    {
        int count = state.count;

        // reset forces
        for (int i = 0; i < count; i++)
        {
            state.forces[i] = Vector2.zero;
        }

        // pairwise
        for (int i = 0; i < count; i++)
        {
            for (int j = i + 1; j < count; j++)
            {
                Vector2 posI = state.positionsByNode[i];
                Vector2 posJ = state.positionsByNode[j];

                Vector2 dir = posI - posJ;
                float dist = dir.magnitude + 0.0001f;
                Vector2 norm = dir / dist;

                int connections = state.connections[i, j];

                float force;
                float restLength = state.desiredCloseDistance / Mathf.Sqrt((float)connections);
                if (connections > 0)
                {
                    //float restLength = state.desiredCloseDistance / Mathf.Sqrt((float)connections);
                    force = -(dist - restLength);
                }
                else
                {
                    force = state.repelStrength;// / Mathf.Sqrt(dist);
                }

                Vector2 f = norm * force;

                state.forces[i] += f;
                state.forces[j] -= f;
            }
        }

        // apply
        for (int i = 0; i < count; i++)
        {
            if (!state.fixedNodes.Contains(i))
            {
                Vector2 pos = state.positionsByNode[i];
                pos += state.forces[i] * state.strengthPer;

                pos.x = Mathf.Clamp01(pos.x);
                pos.y = Mathf.Clamp01(pos.y);

                state.positionsByNode[i] = pos;
            }
        }
    }


    public Vector2 GetEdgeOffset(ForceLayoutState state, MazeNode node, int nodeIndex, MazeEdge edge, float offsetMagnitude)
    {
        int numEdgesOnNode = node.edgeSequence.Count;
        float angleInc = 2f * Mathf.PI / numEdgesOnNode;
        float angle = state.angles[nodeIndex];// 0;
        foreach (int edgeIndex in node.edgeSequence)
        {

            if (mazeEdges[edgeIndex] == edge)
            {
                return new Vector2(Mathf.Sin(angle), Mathf.Cos(angle)) * offsetMagnitude;
            }
            angle += angleInc;
        }
        return Vector2.zero;
    }



    public class EdgeForces
    {
        public HashSet<int> fixedNodes;
        public int[,] connections;
        public int count;

        public float k;
        public float desiredCloseDistance;
        public float springLengthStrength;
        public float edgeNodeAntiParallelTorqueStength;
        public float edgeRepelStrengthFactor;
        public float strengthPer;
        public float rotStrengthPer;
        

        public Vector2[] nodePosition;
        public float[] nodeAngle;
        public List<Vector2>[] offsetsOfNodeEdgesByNodeIndex;
        public Vector2[] nodeForceSum;
        public float[] nodeTorqueSum;
    }
    public EdgeForces InitEdgeLayout(float avgEdgeDists = 0.03f)
    {

        int count = mazeNodes.Count;

        EdgeForces state = new EdgeForces();
        state.count = count;


        state.fixedNodes = new HashSet<int>() { 0, count - 1 };
        state.connections = new int[count, count];
        state.nodePosition = new Vector2[count];
        state.nodeAngle = new float[count];
        state.nodeForceSum = new Vector2[count];
        state.nodeTorqueSum = new float[count];
        state.offsetsOfNodeEdgesByNodeIndex = new List<Vector2>[count];



        // init positions
        for (int i = 0; i < count; i++)
        {
            state.nodePosition[i] = Random.insideUnitCircle * 0.5f + Vector2.one * 0.5f;
            state.nodeAngle[i] = 0;
            state.nodeForceSum[i] = Vector2.zero;
            state.nodeTorqueSum[i] = 0;
        }
        state.nodePosition[0] = Vector2.zero;
        state.nodePosition[count - 1] = Vector2.one;

        // build connections (same logic as before)
        for (int i = 0; i < count; i++)
        {
            MazeNode node = mazeNodes[i];
            Vector2 edgeOffset = Vector2.left * avgEdgeDists * (node.edgeSequence.Count-1) * 0.5f;
            Vector2 edgeOffsetIncrement = Vector2.right * avgEdgeDists;
            List<Vector2> offsetList = new List<Vector2>();
            for (int e = 0; e < node.edgeSequence.Count; e++)
            {
                MazeEdge edge = mazeEdges[node.edgeSequence[e]];
                offsetList.Add(edgeOffset);
                edgeOffset += edgeOffsetIncrement;
                if (!edge.isTeleport)
                {
                    int j = -1;
                    if (edge.nodeA == node)
                        j = mazeNodes.IndexOf(edge.nodeB);
                    else if (edge.nodeB == node)
                        j = mazeNodes.IndexOf(edge.nodeA);

                    if (j >= 0)
                    {
                        state.connections[i, j]++;
                        state.connections[j, i]++;
                    }
                }
            }

            state.offsetsOfNodeEdgesByNodeIndex[i] = offsetList;
        }
        // scale
        state.k = Mathf.Sqrt(1.0f / (float)count);
        state.desiredCloseDistance = 0.3f;// state.k*0.2f;
                                          //  state.repelStrength = 0.3f;// state.k * state.k*0.6f;//
        state.springLengthStrength = 0.5f;
        state.edgeRepelStrengthFactor = 0.3f;
        state.edgeNodeAntiParallelTorqueStength = 1;
        state.strengthPer = 0.001f;
        state.rotStrengthPer = .1f;
        return state;
    }
    public void StepLayout(EdgeForces state)
    {
        int count = state.count;

        // reset forces
        for (int i = 0; i < count; i++)
        {
            state.nodeForceSum[i] = Vector2.zero;
            state.nodeTorqueSum[i] = 0f;
            MazeNode node= mazeNodes[i];
           // List<Vector2> edgeOffsets = state.offsetsOfNodeEdgesByNodeIndex[i];
            Vector2 nodeForceSum = Vector2.zero;
            float nodeTorqueSum = 0;
            for (int j = 0; j < node.edgeSequence.Count; j++)
            {
                int globalEdgeIndex = node.edgeSequence[j];
                Vector2 edgePos = GetNodeEdgePosition(i, j);
                
                MazeEdge edge = mazeEdges[globalEdgeIndex];// GetEdge(node, j);
                MazeNode otherNode = edge.nodeB;
                int otherNodeIndex = mazeNodes.IndexOf(otherNode);
                int otherNodeEdgeIndex = otherNode.edgeSequence.IndexOf(globalEdgeIndex);
                Debug.Log("globalEdgeIndex:"+ globalEdgeIndex+"    otherNode index:" + otherNodeIndex + " otherNodeEdgeIndex:" + otherNodeEdgeIndex + "of "+ otherNode.edgeSequence.Count);
                if (otherNodeIndex == -1) throw new System.Exception("negative node index");
                if (otherNodeEdgeIndex==-1) throw new System.Exception("negative nodeEdgeIndex.   globalEdgeIndex: "+globalEdgeIndex + "  edge sequence in node: "+ string.Join(",",otherNode.edgeSequence));
                Vector2 otherEdgePos = GetNodeEdgePosition(otherNodeIndex, otherNodeEdgeIndex);
                Vector2 edgeForce = GetEdgeEndpointForce(edgePos,otherEdgePos);
                
                if (state.fixedNodes.Contains(otherNodeIndex))
                {
                    edgeForce *= 2f;
                }
                edgeForce *= state.springLengthStrength;
                nodeForceSum += edgeForce;

                //compute torque, add to torque sum
                nodeTorqueSum += Cross(edgeForce, GetNodeEdgeOffset(i, j));
                //  nodeTorqueSum += Cross(edgeForce, GetNodeEdgeOffset(otherNodeIndex,otherNodeEdgeIndex));// state.offsetsOfNodeEdgesByNodeIndex[otherNodeIndex][otherNodeEdgeIndex]);

                // check if node-line is paralel with edge line, rotate to more perpendicular.
                Vector2 nodeLineDir = Rotate(Vector2.right, state.nodeAngle[i]);
                Vector2 edgeDir = (otherEdgePos - edgePos).normalized;
                float howParallel = 1;// 1f-Mathf.Abs(Vector2.Dot(nodeLineDir, edgeDir));
                Vector2 nodeLinePerp = Rotate(Vector2.up, state.nodeAngle[i]);
                float rotDir = -Mathf.Sign(Vector2.Dot(nodeLinePerp, edgeDir));
                nodeTorqueSum += howParallel * rotDir * state.edgeNodeAntiParallelTorqueStength;
            }

            for (int k = 0; k < count; k++)
            {

                nodeForceSum+=GetEdgeEndpointForce(state.nodePosition[i], state.nodePosition[k]) * state.springLengthStrength; 
            }
            state.nodeForceSum[i] = nodeForceSum;
            state.nodeTorqueSum[i] = nodeTorqueSum;
        }

        //edge/edge repulsion
        float edgeRepelStrength = state.edgeRepelStrengthFactor;// state.k * .01f;

        for (int e1 = 0; e1 < mazeEdges.Count; e1++)
        {
            MazeEdge edge1 = mazeEdges[e1];
            (Vector2,Vector2) edgeAStartEnd= GetEdgeEndPositions(e1);
            int edge1NodeAidx = mazeNodes.IndexOf(edge1.nodeA);
            int edge1NodeBidx = mazeNodes.IndexOf(edge1.nodeB);

            Vector2 edge1NodeApos = edgeAStartEnd.Item1;// GetEdgeOffset(state, edgeA.nodeA, a0, edgeA, 0.03f) + state.positionsByNode[a0];//GetPortPos(a0, edgeA);
            Vector2 edge1NodeBpos = edgeAStartEnd.Item2;// GetEdgeOffset(state, edgeA.nodeB, a1, edgeA, 0.03f) + state.positionsByNode[a1];//GetPortPos(a1, edgeA);

            Vector2 midA = (edge1NodeApos + edge1NodeBpos) * 0.5f;

            for (int e2 = e1 + 1; e2 < mazeEdges.Count; e2++)
            {
                MazeEdge edge2 = mazeEdges[e2];


                // skip shared nodes
                /*if (edgeB.nodeA == edgeA.nodeA || edgeB.nodeA == edgeA.nodeB ||
                    edgeB.nodeB == edgeA.nodeA || edgeB.nodeB == edgeA.nodeB)
                    continue;*/

                int edge2NodeAidx = mazeNodes.IndexOf(edge2.nodeA);
                int edge2NodeBidx = mazeNodes.IndexOf(edge2.nodeB);

                int sharedCount = 0;


                int sharedNodeIdx = -1;
                int edge1NotSharedNodeIdx = -1;
                int edge2NotSharedNodeIdx = -1;

                int sharedNodeEdge1Idx=-1;
                int sharedNodeEdge2Idx=-1;
                int notSharedNodeEdge1Idx = -1;
                int notSharedNodeEdge2Idx = -1;
                if (edge2NodeAidx == edge1NodeAidx)
                {

                    sharedNodeEdge1Idx = edge1.nodeA.edgeSequence.IndexOf(e1);
                    sharedNodeEdge2Idx = edge2.nodeA.edgeSequence.IndexOf(e2);
                    notSharedNodeEdge1Idx = edge1.nodeB.edgeSequence.IndexOf(e1);
                    notSharedNodeEdge2Idx = edge2.nodeB.edgeSequence.IndexOf(e2);

                    sharedNodeIdx = edge2NodeAidx;
                    edge1NotSharedNodeIdx = edge1NodeBidx;
                    edge2NotSharedNodeIdx = edge2NodeBidx;
                    sharedCount++;
                }
                if (edge2NodeAidx == edge1NodeBidx)
                {

                    sharedNodeEdge1Idx = edge1.nodeB.edgeSequence.IndexOf(e1);
                    sharedNodeEdge2Idx = edge2.nodeA.edgeSequence.IndexOf(e2);
                    notSharedNodeEdge1Idx = edge1.nodeA.edgeSequence.IndexOf(e1);
                    notSharedNodeEdge2Idx = edge2.nodeB.edgeSequence.IndexOf(e2);

                    sharedNodeIdx = edge2NodeAidx;
                    edge1NotSharedNodeIdx = edge1NodeAidx;
                    edge2NotSharedNodeIdx = edge2NodeBidx;

                    sharedCount++;
                }
                if (edge2NodeBidx == edge1NodeAidx)
                {

                    sharedNodeEdge1Idx = edge1.nodeA.edgeSequence.IndexOf(e1);
                    sharedNodeEdge2Idx = edge2.nodeB.edgeSequence.IndexOf(e2);
                    notSharedNodeEdge1Idx = edge1.nodeB.edgeSequence.IndexOf(e1);
                    notSharedNodeEdge2Idx = edge2.nodeA.edgeSequence.IndexOf(e2);

                    edge1NotSharedNodeIdx = edge1NodeBidx;
                    edge2NotSharedNodeIdx = edge2NodeAidx;

                    sharedNodeIdx = edge2NodeBidx;
                    sharedCount++;
                }
                if (edge2NodeBidx == edge1NodeBidx)
                {

                    sharedNodeEdge1Idx = edge1.nodeB.edgeSequence.IndexOf(e1);
                    sharedNodeEdge2Idx = edge2.nodeB.edgeSequence.IndexOf(e2);
                    notSharedNodeEdge1Idx = edge1.nodeA.edgeSequence.IndexOf(e1);
                    notSharedNodeEdge2Idx = edge2.nodeA.edgeSequence.IndexOf(e2);

                    sharedNodeIdx = edge2NodeBidx;
                    edge1NotSharedNodeIdx = edge1NodeAidx;
                    edge2NotSharedNodeIdx = edge2NodeAidx;

                    sharedCount++;
                }
                if (sharedCount == 2)
                    continue; // same edge

                (Vector2, Vector2) edgeBStartEnd = GetEdgeEndPositions(e2);
                Vector2 edge2NodeApos = edgeBStartEnd.Item1;
                Vector2 edge2NodeBpos = edgeBStartEnd.Item2;

                if (SegmentsIntersect(edge1NodeApos, edge1NodeBpos, edge2NodeApos, edge1NodeApos))
                {



                    Vector2 f;
                    if (sharedCount >0)
                    {
                        //push ALL nodes apart, in direction of seperation on shared node.
                        Vector2 anchorE1 = state.nodePosition[sharedNodeIdx] + GetNodeEdgeOffset(sharedNodeIdx, sharedNodeEdge1Idx);
                        Vector2 anchorE2 = state.nodePosition[sharedNodeIdx] + GetNodeEdgeOffset(sharedNodeIdx, sharedNodeEdge2Idx);
                        Vector2 offset = anchorE1 - anchorE2;
                        Vector2 norm = offset.normalized;
                        f = norm * edgeRepelStrength;
                        Vector2 edge1Dir = (edge1NodeApos - edge1NodeBpos);//.normalized;
                        Vector2 edge2Dir = (edge2NodeApos - edge2NodeBpos);//.normalized;
                        if (edge1Dir.magnitude > edge2Dir.magnitude)
                        {
                            edge1Dir = edge1Dir.normalized;
                            edge2Dir = edge2Dir.normalized;
                        }
                        else
                        {
                            edge1Dir = edge1Dir.normalized;
                            edge2Dir = edge2Dir.normalized;
                        }

                        Vector2 t = edge1Dir * edgeRepelStrength;
                        
                        state.nodeForceSum[sharedNodeIdx] += t;
                        state.nodeTorqueSum[sharedNodeIdx] += Cross(t, GetNodeEdgeOffset(sharedNodeIdx, sharedNodeEdge1Idx));
                        t = edge2Dir * edgeRepelStrength;
                        
                        state.nodeForceSum[sharedNodeIdx] -= t;
                        state.nodeTorqueSum[sharedNodeIdx] += Cross(-t, GetNodeEdgeOffset(sharedNodeIdx, sharedNodeEdge2Idx));

                        f *= -1;
                        state.nodeForceSum[edge1NotSharedNodeIdx] -= f;
                        state.nodeTorqueSum[edge1NotSharedNodeIdx] += Cross(-f, GetNodeEdgeOffset(edge1NotSharedNodeIdx, notSharedNodeEdge1Idx));
                        state.nodeForceSum[edge2NotSharedNodeIdx] += f;
                        state.nodeTorqueSum[edge2NotSharedNodeIdx] += Cross(f, GetNodeEdgeOffset(edge2NotSharedNodeIdx, notSharedNodeEdge2Idx));


                    }
                    else //if(false)
                    {


                        Vector2 midB = (edge2NodeApos + edge2NodeBpos) * 0.5f;

                        Vector2 d = midA - midB;
                        float dist = d.magnitude + 0.0001f;
                        Vector2 norm = d / dist;

                        float force = edgeRepelStrength;/// dist;

                        f = norm * force;
                        //f*=Mathf.Sign(Orient(pA0, pA1, midB));
                        f *= Mathf.Sign(Orient2(edge1NodeApos, edge1NodeBpos, edge2NodeApos, edge2NodeBpos));



                        state.nodeForceSum[edge1NodeAidx] += f;
                        state.nodeTorqueSum[edge1NodeAidx] += Cross(f, GetNodeEdgeOffset(edge1NodeAidx, edge1.nodeA.edgeSequence.IndexOf(e1)));

                        state.nodeForceSum[edge1NodeBidx] += f;
                        state.nodeTorqueSum[edge1NodeBidx] += Cross(f, GetNodeEdgeOffset(edge1NodeBidx, edge1.nodeB.edgeSequence.IndexOf(e1)));

                        state.nodeForceSum[edge2NodeAidx] -= f;
                        state.nodeTorqueSum[edge2NodeAidx] += Cross(f, GetNodeEdgeOffset(edge2NodeAidx, edge2.nodeA.edgeSequence.IndexOf(e2)));

                        state.nodeForceSum[edge2NodeBidx] -= f;
                        state.nodeTorqueSum[edge2NodeBidx] += Cross(f, GetNodeEdgeOffset(edge2NodeBidx, edge2.nodeB.edgeSequence.IndexOf(e2)));
                    }

                    /*
                    state.nodeForceSum[a0] += f;
                    state.nodeTorqueSum[a0] += Cross(f, GetNodeEdgeOffset(a0, edgeA.nodeA.edgeSequence.IndexOf(e1)));
                    state.nodeForceSum[a1] += f;
                    state.nodeTorqueSum[a1] += Cross(f, GetNodeEdgeOffset(a1, edgeA.nodeB.edgeSequence.IndexOf(e1)));

                    state.nodeForceSum[b0] -= f;
                    state.nodeTorqueSum[b0] += Cross(f, GetNodeEdgeOffset(b0, edgeB.nodeA.edgeSequence.IndexOf(e2)));
                    state.nodeForceSum[b1] -= f;
                    state.nodeTorqueSum[b1] += Cross(f, GetNodeEdgeOffset(b1, edgeB.nodeB.edgeSequence.IndexOf(e2)));
                    */
                }
            }




        }


        //update positions, rotations of nodes
        for (int i = 0; i < count; i++)
        {
            if (!state.fixedNodes.Contains(i))
            {
                Vector2 force = state.nodeForceSum[i];
                float forceMag = force.magnitude;
                if (forceMag > 0.5f)// max force mag allowed
                {
                    force/=forceMag;
                    force *= 0.5f; // set magnitude to max
                }
                Vector2 pos = state.nodePosition[i];
                pos += force * state.strengthPer;
                if (pos.x < 0) pos.x = 0;
                if (pos.y < 0) pos.y = 0;
                if (pos.x > 1) pos.x = 1;
                if (pos.y > 1) pos.y = 1;

                state.nodePosition[i] = pos;
            }
            state.nodeAngle[i] += state.nodeTorqueSum[i] * state.rotStrengthPer;
        }

        float Orient(Vector2 a, Vector2 b, Vector2 p)
        {
            return Cross(b - a, p - a);
        }
        float Orient2(Vector2 a, Vector2 b, Vector2 p, Vector2 q)
        {
            return Cross(b - a, p - q);
        }
        float Cross(Vector2 a, Vector2 b)
        {
            return a.x * b.y - a.y * b.x;
        }

        Vector2 GetNodeEdgeOffset(int nodeIndex, int nodeEdgeIndex)
        {
            return Rotate(state.offsetsOfNodeEdgesByNodeIndex[nodeIndex][nodeEdgeIndex], state.nodeAngle[nodeIndex]);
        }

        Vector2 GetNodeEdgePosition(int nodeIndex, int nodeEdgeIndex)
        {
            return state.nodePosition[nodeIndex] + Rotate(state.offsetsOfNodeEdgesByNodeIndex[nodeIndex][nodeEdgeIndex], state.nodeAngle[nodeIndex]);
        }

        (Vector2,Vector2) GetEdgeEndPositions(int edgeIndex)
        {
            MazeEdge edge = mazeEdges[edgeIndex];
            int nodeAIndex = mazeNodes.IndexOf(edge.nodeA);
            int nodeAEdgeIndex = edge.nodeA.edgeSequence.IndexOf(edgeIndex);
            int nodeBIndex = mazeNodes.IndexOf(edge.nodeB);
            int nodeBEdgeIndex = edge.nodeB.edgeSequence.IndexOf(edgeIndex);
            return (GetNodeEdgePosition(nodeAIndex, nodeAEdgeIndex), GetNodeEdgePosition(nodeBIndex, nodeBEdgeIndex));

        }
        Vector2 Rotate(Vector2 v, float angleRad)
        {
            float cos = Mathf.Cos(angleRad);
            float sin = Mathf.Sin(angleRad);

            float x = v.x * cos - v.y * sin;
            float y = v.x * sin + v.y * cos;

            return new Vector2(x, y);
        }

        Vector2 GetEdgeEndpointForce(Vector2 edgePos0, Vector2 edgePos1)
        {
            Vector2 posI = edgePos0;
            Vector2 posJ = edgePos1;

            Vector2 dir = posI - posJ;
            float dist = dir.magnitude + 0.0001f;
            Vector2 norm = dir / dist;

          //  int connections = 1;

            float force;
            float restLength = state.desiredCloseDistance;// / Mathf.Sqrt((float)connections + 1);
            float offset = (dist - restLength);
            force = -((dist - restLength) / restLength);

            //f=((x-L)/L)^2
            //force = ((dist - restLength) / restLength);
            //force *= force;
            //force *= -Mathf.Sign(offset);

            //f=L( (L/(2L-x))-1)
            //force = restLength * ((restLength / (2f * restLength - offset)) - 1f) * Mathf.Sign(offset);

            //f=old
            //force = state.repelStrength * offset * offset;

            Vector2 f = norm * force;
            return f;
        }

        static bool SegmentsIntersect(Vector2 a1, Vector2 a2, Vector2 b1, Vector2 b2) 
        {
            float o1 = Orient(a1, a2, b1);
            float o2 = Orient(a1, a2, b2);
            float o3 = Orient(b1, b2, a1);
            float o4 = Orient(b1, b2, a2);

            if (o1 * o2 < 0f && o3 * o4 < 0f)
            {
                return true; // proper intersection
            }

            // collinear cases
            if (o1 == 0f && OnSegment(a1, a2, b1)) return true;
            if (o2 == 0f && OnSegment(a1, a2, b2)) return true;
            if (o3 == 0f && OnSegment(b1, b2, a1)) return true;
            if (o4 == 0f && OnSegment(b1, b2, a2)) return true;

            return false;


            static float Orient(Vector2 a, Vector2 b, Vector2 c)
            {
                // cross((b - a), (c - a))
                return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
            }

            static bool OnSegment(Vector2 a, Vector2 b, Vector2 p)
            {
                return p.x >= Mathf.Min(a.x, b.x) &&
                       p.x <= Mathf.Max(a.x, b.x) &&
                       p.y >= Mathf.Min(a.y, b.y) &&
                       p.y <= Mathf.Max(a.y, b.y);
            }
        }
    }





}

public class TopoEdgeForcer
{
    MazeTopology topo;

}


public class ExampleTopologies
{
    static public MazeTopology BuildSampleTopology()
    {
        var topology = new MazeTopology();

        var start = new MazeNode("Start",true);
        var mainPath = new MazeNode("MainPath");
        var branch1 = new MazeNode("Branch1");
        var deadEnd2 = new MazeNode("DeadEnd2");
        var branch1Retun = new MazeNode("branch1Retun");
        var end = new MazeNode("End",false,true);

        topology.mazeNodes.AddRange(new[] { start, mainPath, branch1, deadEnd2, branch1Retun, end });

        // Create edges in topology
        topology.mazeEdges.Add(new MazeEdge(start, mainPath));// 0
        topology.mazeEdges.Add(new MazeEdge(mainPath, branch1));// 1
        topology.mazeEdges.Add(new MazeEdge(mainPath, deadEnd2));// 2
        topology.mazeEdges.Add(new MazeEdge(deadEnd2,mainPath));// 3
        topology.mazeEdges.Add(new MazeEdge(branch1, branch1Retun));// 4
        topology.mazeEdges.Add(new MazeEdge(branch1Retun, branch1));// 5
        topology.mazeEdges.Add(new MazeEdge(branch1Retun, mainPath));// 6
        topology.mazeEdges.Add(new MazeEdge(mainPath, end));// 7

        // start node sequence
        start.edgeSequence.Add(0);

        // MainPath sequence
        mainPath.edgeSequence.Add(0); //in          
        mainPath.edgeSequence.Add(1);           
        mainPath.edgeSequence.Add(2);
        mainPath.edgeSequence.Add(3); //in
        mainPath.edgeSequence.Add(6); //in
        mainPath.edgeSequence.Add(7);           

        // Branch1 sequence
        branch1.edgeSequence.Add(1);//in
        branch1.edgeSequence.Add(4);
        branch1.edgeSequence.Add(5);//in

        // DeadEnd2 sequence
        deadEnd2.edgeSequence.Add(2);//in
        deadEnd2.edgeSequence.Add(3);

        // branch1Retun sequence
        branch1Retun.edgeSequence.Add(4);//in
        branch1Retun.edgeSequence.Add(5);
        branch1Retun.edgeSequence.Add(6);

        // End sequence
        end.edgeSequence.Add(7);
        return topology;
    }
    static public MazeTopology BuildSampleTopology2()
    {
        var topology = new MazeTopology();

        var start = new MazeNode("Start");
        var mainPath = new MazeNode("MainPath");
        var branch1 = new MazeNode("Branch1");
        var deadEnd2 = new MazeNode("DeadEnd2");
        var end = new MazeNode("End");

        topology.mazeNodes.AddRange(new[] { start, mainPath, branch1, deadEnd2, end });

        // Create edges in topology
        topology.mazeEdges.Add(new MazeEdge(start, mainPath));// 0
        topology.mazeEdges.Add(new MazeEdge(mainPath, branch1));// 1
        topology.mazeEdges.Add(new MazeEdge(mainPath, deadEnd2));// 2
        topology.mazeEdges.Add(new MazeEdge(deadEnd2, branch1));// 3 - this example is different, because this deadEnd2 edge has been changes to return to branch1, rather than mainPath(old)
        topology.mazeEdges.Add(new MazeEdge(branch1, mainPath));// 4
        topology.mazeEdges.Add(new MazeEdge(mainPath, end));// 5

        // start node sequence
        start.edgeSequence.Add(0);

        // MainPath sequence
        mainPath.edgeSequence.Add(0); //in          
        mainPath.edgeSequence.Add(1);
        mainPath.edgeSequence.Add(2);
        //this example is different, because this edge has been moved to branch1
        mainPath.edgeSequence.Add(4); //in
        mainPath.edgeSequence.Add(5);

        // Branch1 sequence
        branch1.edgeSequence.Add(1);//in
        branch1.edgeSequence.Add(3);//in: this example is different, because this edge has been moved from mainPath
        branch1.edgeSequence.Add(4);

        // DeadEnd2 sequence
        deadEnd2.edgeSequence.Add(2);//in
        deadEnd2.edgeSequence.Add(3);

        // End sequence
        end.edgeSequence.Add(5);
        return topology;
    }
}
