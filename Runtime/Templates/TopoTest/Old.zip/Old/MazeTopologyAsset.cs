using UnityEngine;
using System.Collections.Generic;

[CreateAssetMenu(menuName = "Maze/Topology")]
public class MazeTopologyAsset : ScriptableObject
{
    public List<MazeNodeData> nodes = new List<MazeNodeData>();
    public List<MazeEdgeData> edges = new List<MazeEdgeData>();

    public MazeTopology ToTopology()
    {
        var topology = new MazeTopology();

        // Create nodes
        var nodeDict = new Dictionary<int, MazeNode>();
        foreach (var nodeData in nodes)
        {
            var node = new MazeNode(nodeData.name, nodeData.isStart, nodeData.isEnd);
            topology.mazeNodes.Add(node);
            nodeDict[nodeData.id] = node;
        }

        // Create edges and add to sequences
        foreach (var edgeData in edges)
        {
            var nodeA = nodeDict[edgeData.nodeAId];
            var nodeB = nodeDict[edgeData.nodeBId];
            var edge = new MazeEdge(nodeA, nodeB, edgeData.isTeleport);

            int edgeIndex = topology.mazeEdges.Count;
            topology.mazeEdges.Add(edge);

            // Add to sequences
            foreach (int seqIndex in edgeData.nodeASequenceIndices)
                nodeA.edgeSequence.Add(edgeIndex);

            foreach (int seqIndex in edgeData.nodeBSequenceIndices)
                nodeB.edgeSequence.Add(-(edgeIndex + 1));
        }

        return topology;
    }
}

[System.Serializable]
public class MazeNodeData
{
    public int id;
    public string name;
    public bool isStart;
    public bool isEnd;
    public Vector2 editorPosition;  // For visual editor
    public List<int> edgeSequence = new List<int>();  //int will be negative index 
}

[System.Serializable]
public class MazeEdgeData
{
    public int id;
    public int nodeAId;
    public int nodeBId;
    public bool isTeleport;

    // Track which sequence positions this edge occupies in each node
    public List<int> nodeASequenceIndices = new List<int>();  // Positive indices
    public List<int> nodeBSequenceIndices = new List<int>();  // Will be negated
}