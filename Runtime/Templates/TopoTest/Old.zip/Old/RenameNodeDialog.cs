﻿#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

public class RenameNodeDialog : EditorWindow
{
    private MazeNodeData nodeToRename;
    private MazeTopologyAsset topology;
    private string newName;
    private bool doFocusOnText = true;
    public void Initialize(MazeNodeData node, MazeTopologyAsset topo)
    {
        nodeToRename = node;
        topology = topo;
        newName = node.name;
        EditorGUI.FocusTextInControl("RenameField");
    }

    private void OnGUI()
    {
        GUILayout.Label("Rename Node", EditorStyles.boldLabel);

        EditorGUILayout.Space();

        EditorGUILayout.LabelField("New Name:");
        GUI.SetNextControlName("RenameField");
        newName = EditorGUILayout.TextField(newName);
        if (doFocusOnText && Event.current.type == EventType.Repaint)
        {
            EditorGUI.FocusTextInControl("RenameField");
            doFocusOnText = false;
        }

        EditorGUILayout.Space();

        EditorGUILayout.BeginHorizontal();

        if (GUILayout.Button("OK", GUILayout.Width(100)))
        {
            if (!string.IsNullOrWhiteSpace(newName))
            {
                nodeToRename.name = newName;
                EditorUtility.SetDirty(topology);
                Close();
            }
        }

        if (GUILayout.Button("Cancel", GUILayout.Width(100)))
        {
            Close();
        }

        EditorGUILayout.EndHorizontal();
    }

    private void OnEnable()
    {
        minSize = new Vector2(300, 100);
        maxSize = new Vector2(300, 100);
        doFocusOnText = true;
        Repaint();
    }
}
#endif