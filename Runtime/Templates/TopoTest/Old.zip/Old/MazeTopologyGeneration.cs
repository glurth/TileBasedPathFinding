// ============================================================
// FILE: MazeTopologyGeneration.cs
//
// Drop this file into your project alongside GenericMazeMap.cs
// and MazeTopology.cs.
//
// Contains:
//   - Extension/helper methods added to MazeTopology  (partial class)
//   - GenerateFromTopology(...) member function for GenericMazeMap<T>
//
// Usage:
//   Instead of calling  myMaze.GenerateMaze()
//   call               myMaze.GenerateFromTopology(topology)
//   or async:          await myMaze.GenerateFromTopologyAsync(topology, taskContext)
// ============================================================

using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using Cysharp.Threading.Tasks;
using EyE.Threading;

// ── MazeTopology helpers ────────────────────────────────────────────────────

public partial class MazeTopology   // mark the original class partial, or place these as new methods directly in MazeTopology.cs
{
    // -----------------------------------------------------------------------
    // Topology traversal helpers
    // -----------------------------------------------------------------------

    /// <summary>
    /// Returns every edge that is outbound from <paramref name="node"/>
    /// (i.e. edges where nodeA == node), in edgeSequence order.
    /// </summary>
    public IEnumerable<(int seqIndex, int edgeIndex, MazeEdge edge)> OutboundEdgesInOrder(MazeNode node)
    {
        for (int s = 0; s < node.edgeSequence.Count; s++)
        {
            int eIdx = node.edgeSequence[s];
            MazeEdge edge = mazeEdges[eIdx];
            if (edge.nodeA == node)
                yield return (s, eIdx, edge);
        }
    }

    /// <summary>
    /// Returns every edge that is inbound to <paramref name="node"/>
    /// (i.e. edges where nodeB == node), in edgeSequence order.
    /// </summary>
    public IEnumerable<(int seqIndex, int edgeIndex, MazeEdge edge)> InboundEdgesInOrder(MazeNode node)
    {
        for (int s = 0; s < node.edgeSequence.Count; s++)
        {
            int eIdx = node.edgeSequence[s];
            MazeEdge edge = mazeEdges[eIdx];
            if (edge.nodeB == node)
                yield return (s, eIdx, edge);
        }
    }

    /// <summary>
    /// Returns all edges (inbound and outbound) for <paramref name="node"/>,
    /// in edgeSequence order, together with whether each is inbound.
    /// </summary>
    public IEnumerable<(int seqIndex, int edgeIndex, MazeEdge edge, bool isInbound)> AllEdgesInOrder(MazeNode node)
    {
        for (int s = 0; s < node.edgeSequence.Count; s++)
        {
            int eIdx = node.edgeSequence[s];
            MazeEdge edge = mazeEdges[eIdx];
            bool inbound = (edge.nodeB == node);
            yield return (s, eIdx, edge, inbound);
        }
    }

    /// <summary>
    /// Produces a processing order for nodes such that every inbound edge's
    /// source node is processed before this node (topological sort).
    /// Cycles are broken arbitrarily (the topology may be cyclic for loops).
    /// Nodes with isMazeStart come first.
    /// </summary>
    public List<MazeNode> TopologicalOrder()
    {
        // Kahn's algorithm — cycles are handled by draining the remaining
        // set once the queue empties (handles loops/bidirectional passages).
        var inDegree = new Dictionary<MazeNode, int>();
        foreach (MazeNode n in mazeNodes) inDegree[n] = 0;

        foreach (MazeEdge e in mazeEdges)
            if (!e.isTeleport && e.nodeB != null)
                inDegree[e.nodeB]++;

        var queue = new Queue<MazeNode>();

        // Seed with start nodes first, then any zero-in-degree nodes.
        foreach (MazeNode n in mazeNodes)
            if (n.isMazeStart) { queue.Enqueue(n); inDegree[n] = -1; }

        foreach (MazeNode n in mazeNodes)
            if (inDegree[n] == 0 && !n.isMazeStart) queue.Enqueue(n);

        var result = new List<MazeNode>();
        var enqueued = new HashSet<MazeNode>(queue);

        while (result.Count < mazeNodes.Count)
        {
            if (queue.Count == 0)
            {
                // Remaining nodes are in a cycle — just pick one to break it.
                foreach (MazeNode remaining in mazeNodes)
                {
                    if (!enqueued.Contains(remaining))
                    { queue.Enqueue(remaining); enqueued.Add(remaining); break; }
                }
            }

            MazeNode current = queue.Dequeue();
            result.Add(current);

            foreach (MazeEdge e in mazeEdges)
            {
                if (e.isTeleport) continue;
                if (e.nodeA != current) continue;
                MazeNode successor = e.nodeB;
                if (enqueued.Contains(successor)) continue;
                inDegree[successor]--;
                if (inDegree[successor] <= 0)
                { queue.Enqueue(successor); enqueued.Add(successor); }
            }
        }

        return result;
    }

    // -----------------------------------------------------------------------
    // Validation
    // -----------------------------------------------------------------------

    /// <summary>
    /// Throws <see cref="System.InvalidOperationException"/> if the topology
    /// contains structural errors (missing nodes/edges, self-loops, etc.).
    /// Does NOT validate 2-D embeddability — that is checked during generation.
    /// </summary>
    public void ValidateTopology()
    {
        if (mazeNodes == null || mazeNodes.Count == 0)
            throw new System.InvalidOperationException("MazeTopology has no nodes.");
        if (mazeEdges == null)
            throw new System.InvalidOperationException("MazeTopology has null edge list.");

        int startCount = mazeNodes.Count(n => n.isMazeStart);
        int endCount   = mazeNodes.Count(n => n.isMazeEnd);
        if (startCount == 0) throw new System.InvalidOperationException("Topology has no MazeStart node.");
        if (endCount   == 0) throw new System.InvalidOperationException("Topology has no MazeEnd node.");

        for (int i = 0; i < mazeEdges.Count; i++)
        {
            MazeEdge e = mazeEdges[i];
            if (e.nodeA == null || e.nodeB == null)
                throw new System.InvalidOperationException($"Edge {i} has a null node reference.");
            if (e.nodeA == e.nodeB)
                throw new System.InvalidOperationException($"Edge {i} is a self-loop on node '{e.nodeA.name}'.");
            if (!mazeNodes.Contains(e.nodeA))
                throw new System.InvalidOperationException($"Edge {i} nodeA '{e.nodeA.name}' is not in mazeNodes.");
            if (!mazeNodes.Contains(e.nodeB))
                throw new System.InvalidOperationException($"Edge {i} nodeB '{e.nodeB.name}' is not in mazeNodes.");
        }

        foreach (MazeNode node in mazeNodes)
        {
            foreach (int seq in node.edgeSequence)
            {
                if (seq < 0 || seq >= mazeEdges.Count)
                    throw new System.InvalidOperationException(
                        $"Node '{node.name}' edgeSequence references out-of-range edge index {seq}.");

                MazeEdge e = mazeEdges[seq];
                if (e.nodeA != node && e.nodeB != node)
                    throw new System.InvalidOperationException(
                        $"Node '{node.name}' edgeSequence references edge {seq} " +
                        $"which does not connect to this node.");
            }
        }
    }
}


// ── GenericMazeMap<T> — topology-driven generation ──────────────────────────

namespace EyE.Maps.Templates
{
    public abstract partial class GenericMazeMap<T>
    {
        // ===================================================================
        //  PUBLIC ENTRY POINTS
        // ===================================================================
        
        /// <summary>
        /// Synchronous topology-driven maze generation.
        /// Call instead of <see cref="GenerateMaze"/>.
        /// </summary>
        public void GenerateFromTopology(MazeTopology topology)
        {
            GenerateFromTopologyAsync(topology, new TaskHandler(false))
                .AsTask().GetAwaiter().GetResult();
        }

        /// <summary>
        /// Async topology-driven maze generation.
        /// Call instead of <see cref="GenerateMazeAsync"/>.
        /// </summary>
        public async UniTask GenerateFromTopologyAsync(MazeTopology topology, TaskHandler taskContext)
        {
            // ── 0. Validate ──────────────────────────────────────────────
            topology.ValidateTopology();

            // ── 1. Initialise walls / visited (all walls up, none visited) ─
            await InitialiseWallsAsync(taskContext);

            // ── 2. Set up teleporters for topology teleport edges ─────────
            teleporters = BuildTeleporterCollection(topology);

            // ── 3. Assign tiles to each node (the core algorithm) ─────────
            // nodeFirstTile[edge index]  = tile at the "nodeA side" of that edge
            // nodeSecondTile[edge index] = tile at the "nodeB side" of that edge
            // These are the tiles whose shared wall gets removed (non-teleport edges).
            var edgeNodeATile = new Dictionary<int, T>();   // tile belonging to nodeA
            var edgeNodeBTile = new Dictionary<int, T>();   // tile belonging to nodeB

            // nodeTiles[node] = all tiles assigned to that node's passage (in passage order)
            var nodeTiles = new Dictionary<MazeNode, List<T>>();

            List<MazeNode> order = topology.TopologicalOrder();

            foreach (MazeNode node in order)
            {
                Debug.Log("carving passage for node " + node.name);
                List<T> passage = await CarveNodePassageAsync(
                    node, topology, edgeNodeATile, edgeNodeBTile, nodeTiles, taskContext);

                nodeTiles[node] = passage;
            }

            // ── 4. Remove walls at every non-teleport edge junction ───────
            foreach (MazeEdge edge in topology.mazeEdges)
            {
                if (edge.isTeleport) continue;

                int edgeIdx = topology.mazeEdges.IndexOf(edge);

                if (!edgeNodeATile.TryGetValue(edgeIdx, out T tileA) ||
                    !edgeNodeBTile.TryGetValue(edgeIdx, out T tileB))
                {
                    throw new System.InvalidOperationException(
                        $"Edge {edgeIdx} ({edge.nodeA.name}→{edge.nodeB.name}) never had junction tiles assigned. " +
                        "The topology may require more map tiles than are available.");
                }

                RemoveWallBetween(tileA, tileB);
            }

            // ── 5. Map start/end fields to topology start/end nodes ───────
            MazeNode startNode = topology.mazeNodes.FirstOrDefault(n => n.isMazeStart);
            MazeNode endNode   = topology.mazeNodes.FirstOrDefault(n => n.isMazeEnd);

            if (startNode != null && nodeTiles.TryGetValue(startNode, out List<T> startTiles) && startTiles.Count > 0)
                start = startTiles[0];
            if (endNode   != null && nodeTiles.TryGetValue(endNode,   out List<T> endTiles)   && endTiles.Count > 0)
                end = endTiles[endTiles.Count - 1];

            await taskContext.Yield();
        }


        // ===================================================================
        //  PRIVATE HELPERS
        // ===================================================================

        // -------------------------------------------------------------------
        // Initialise walls and visited state (mirrors existing GenerateMazeAsync setup)
        // -------------------------------------------------------------------
        private async UniTask InitialiseWallsAsync(TaskHandler taskContext)
        {
            walls.Clear();
            oneWayWalls.Clear();
            visited.Clear();

            int total = 0;
            foreach (T _ in allMapCoords) total++;
            int done = 0;

            foreach (T coord in allMapCoords)
            {
                int n = coord.NumberOfNeighbors();
                bool[] w  = new bool[n];
                bool[] ow = new bool[n];
                for (int i = 0; i < n; i++) { w[i] = true; ow[i] = false; }

                walls[coord]       = w;
                oneWayWalls[coord] = ow;
                visited[coord]     = false;

                done++;
                taskContext.IncrementProgress((float)done / total * 0.15f); // first 15 % of progress
                await taskContext.Yield();
            }
            Debug.Log("visited coords all false");
        }

        // -------------------------------------------------------------------
        // Build TeleporterCollection from any topology teleport edges.
        // -------------------------------------------------------------------
        private TeleporterCollection BuildTeleporterCollection(MazeTopology topology)
        {
            // For now there is no spatial tile assigned yet — teleport edges in the
            // topology are handled later during passage carving.  We return an empty
            // collection here; if you extend the topology to carry explicit tile
            // coords for teleport endpoints, wire them in here.
            return new TeleporterCollection();
        }

        // -------------------------------------------------------------------
        // Carve the passage for a single node.
        //
        // Strategy:
        //   - A node's passage is a contiguous chain of tiles.
        //   - Each edge in edgeSequence is a junction that falls at a
        //     specific relative position along the passage (first → last).
        //   - Inbound edges contribute their already-placed nodeB tile as the
        //     starting anchor of this node's passage.
        //   - Outbound edges need us to grow until we can place a tile that
        //     is spatially adjacent to the nodeB node's future entry tile
        //     (but we do it lazily — we record our "exit tile" and later the
        //     next node picks it up as its entry tile).
        //
        // The algorithm:
        //   1. Determine the entry tile for this node:
        //      - The FIRST inbound edge in the sequence provides the tile
        //        already placed in edgeNodeBTile by the predecessor node.
        //      - If the node has NO inbound edges (e.g. the start node),
        //        pick an unvisited tile at random near the maze start.
        //   2. Walk the edgeSequence:
        //      - Between consecutive edge slots, grow the passage by DFS
        //        through unvisited tiles.
        //      - At each outbound edge slot, record the current tip tile as
        //        edgeNodeATile[edgeIdx]; the successor node will grow
        //        toward it.
        //      - At each inbound edge slot beyond the first, the tile was
        //        already placed by a predecessor — snap the passage tip to it.
        // -------------------------------------------------------------------
        private async UniTask<List<T>> CarveNodePassageAsync(
            MazeNode node,
            MazeTopology topology,
            Dictionary<int, T> edgeNodeATile,
            Dictionary<int, T> edgeNodeBTile,
            Dictionary<MazeNode, List<T>> nodeTiles,
            TaskHandler taskContext)
        {
            List<T> passage = new List<T>();

            // ── Determine entry tile ─────────────────────────────────────
            T entryTile = default;
            bool hasEntry = false;

            // First inbound edge (if any) provides our entry tile.
            foreach (var (seqIndex, edgeIndex, edge, isInbound) in topology.AllEdgesInOrder(node))
            {
                if (!isInbound) continue;
                if (edgeNodeBTile.TryGetValue(edgeIndex, out T prePlaced))
                {
                    entryTile = prePlaced;
                    hasEntry  = true;
                    break;
                }
            }

            if (!hasEntry)
            {
                // No inbound edges (or predecessor hasn't run yet due to cycle).
                // Pick the first unvisited tile available (start node case).
                if(!TryPickStartingTile(out entryTile))
                //entryTile = PickStartingTile();
                //if (entryTile.Equals(default(T)))
                    throw new System.InvalidOperationException(
                        $"Node '{node.name}' has no inbound edges and no free tiles remain for an entry tile.");
            }

            if (visited[entryTile])
            {
                // This tile was already consumed — it was placed as the nodeB tile
                // for this edge by the predecessor, which is correct; it belongs to
                // BOTH passages at the junction boundary (the wall between them is
                // removed, but the tile itself is the predecessor's last tile).
                // We start our passage from the entry tile's unvisited neighbor.
                
                if (TryFindUnvisitedNeighborOf(entryTile, out T result))
                    entryTile = result;
                else
                //entryTile = FindUnvisitedNeighborOf(entryTile);
                //if (entryTile.Equals(default(T)))
                    throw new System.InvalidOperationException(
                        $"Node '{node.name}': entry tile has no unvisited neighbors. " +
                        "The maze grid may be too small for this topology.");
            }
            Debug.Log("visited entryTile[" + entryTile+"] : true");
            visited[entryTile] = true;
            passage.Add(entryTile);

            // ── Walk the edge sequence ────────────────────────────────────
            // We treat each edge slot as a "waypoint" along the passage.
            // Between waypoints we do a short random DFS to add variety.

            T currentTip = entryTile;

            var allEdgesInOrder = topology.AllEdgesInOrder(node).ToList();

            for (int s = 0; s < allEdgesInOrder.Count; s++)
            {
                var (seqIndex, edgeIndex, edge, isInbound) = allEdgesInOrder[s];

                if (isInbound)
                {
                    // This inbound edge means another passage merges into ours here.
                    // If it's the very first entry we already handled it above.
                    // For subsequent inbound edges (mid-passage junctions from loops):
                    //   the tile joining us should be an already-placed nodeB tile.
                    //   Record it, then continue our passage from the current tip.
                    if (!edgeNodeBTile.ContainsKey(edgeIndex))
                    {
                        // Predecessor hasn't run yet (cycle) — record our current tip
                        // as the nodeB tile so the other side can connect.
                        edgeNodeBTile[edgeIndex] = currentTip;
                    }
                    // No passage growth needed for inbound junctions — the wall
                    // removal between nodeA's exit tile and our tile happens in step 4.
                }
                else // outbound
                {
                    // We need to grow the passage a bit before planting the exit tile.
                    // How much to grow is proportional to the remaining unvisited tiles
                    // divided by the remaining edge slots, giving roughly uniform spacing.
                    int unvisitedCount   = CountUnvisited();
                    int remainingEdges   = allEdgesInOrder.Count - s;
                    int targetGrowth     = Mathf.Max(1, unvisitedCount / Mathf.Max(1, remainingEdges));
                    // Clamp to avoid excessively long passages for any one segment.
                    targetGrowth = Mathf.Min(targetGrowth, 20);

                    List<T> segment = await GrowPassageSegmentAsync(
                        currentTip, targetGrowth, taskContext);

                    passage.AddRange(segment);
                    if (segment.Count > 0)
                        currentTip = segment[segment.Count - 1];

                    // Record this tip as the outbound junction tile for nodeA.
                    edgeNodeATile[edgeIndex] = currentTip;

                    // Also pre-record the nodeB tile as the unvisited neighbor of
                    // our tip in the direction of the successor node — we pick a
                    // free neighbor and "promise" it to the next node as its entry.
                    if (!edge.isTeleport)
                    {
                        if (TryFindUnvisitedNeighborOf(entryTile, out T promisingNeighbor))
                     //       T promisingNeighbor = FindUnvisitedNeighborOf(currentTip);
                     //   if (!promisingNeighbor.Equals(default(T)))
                        {
                            // Mark it visited so nothing else can claim it.
                            Debug.Log("visited promisingNeighbor [" + promisingNeighbor + "] : true");
                            visited[promisingNeighbor] = true;
                            edgeNodeBTile[edgeIndex] = promisingNeighbor;
                        }
                        // If no neighbor is free, leave it unset — step 4 will throw
                        // an informative error if it truly can't be resolved.
                    }
                }

                await taskContext.Yield();
            }

            taskContext.IncrementProgress(0.5f / topology.mazeNodes.Count);
            return passage;
        }

        // -------------------------------------------------------------------
        // Grow a short DFS passage segment from a given start tile.
        // Stops when targetSteps tiles have been added, or no unvisited
        // neighbors remain.  Returns the tiles added (not including start).
        // -------------------------------------------------------------------
        private async UniTask<List<T>> GrowPassageSegmentAsync(
            T from, int targetSteps, TaskHandler taskContext)
        {
            var segment = new List<T>();
            var stack   = new Stack<T>();
            stack.Push(from);

            while (stack.Count > 0 && segment.Count < targetSteps)
            {
                T current = stack.Peek();
                List<T> unvisitedNeighbors = GetUnvisitedSpatialNeighbors(current);

                if (unvisitedNeighbors.Count > 0)
                {
                    T next = unvisitedNeighbors[random.Next(unvisitedNeighbors.Count)];
                    Debug.Log("visited next[" + next + "] : true");
                    visited[next] = true;
                    segment.Add(next);
                    stack.Push(next);
                }
                else
                {
                    stack.Pop();
                }

                await taskContext.Yield();
            }

            return segment;
        }

        // -------------------------------------------------------------------
        // Get spatially adjacent, in-bounds, unvisited neighbors of a tile.
        // (Does not use teleporters — passage carving is purely spatial.)
        // -------------------------------------------------------------------
        private List<T> GetUnvisitedSpatialNeighbors(T tile)
        {
            var result = new List<T>();
            foreach (T neighbor in tile.GetSpatialNeighbors())
            {
                if (IsWithinBounds(neighbor) && !visited[neighbor])
                    result.Add(neighbor);
            }
            return result;
        }

        // -------------------------------------------------------------------
        // Pick any unvisited tile on the map (used when a node has no inbound
        // edges and needs a fresh starting tile — e.g. the start node).
        // -------------------------------------------------------------------
        private bool TryPickStartingTile(out T result)
        {
            Debug.Log("Start[" + start + "] visited: " + visited[start]);
            // Prefer the maze's declared start coord if it's free.
            if (!visited[start])
            {
                result = start;
                return true;
            }


            // Otherwise walk all coords and return the first unvisited one.
            foreach (T coord in allMapCoords)
                if (!visited[coord])
                {
                    result = coord;
                    return true;
                }
            result = default(T);
            return false;  // none available
        }

        // -------------------------------------------------------------------
        // Find any unvisited in-bounds spatial neighbor of a tile, or default.
        // -------------------------------------------------------------------
        private bool TryFindUnvisitedNeighborOf(T tile, out T result)
        {
            foreach (T n in tile.GetSpatialNeighbors())
                if (IsWithinBounds(n) && !visited[n])
                {
                    result = n;
                    return true;
                }
            result = default(T);
            return false;
        }

        // -------------------------------------------------------------------
        // Count how many tiles are currently unvisited.
        // (Intentionally not cached — called infrequently; optimize later.)
        // -------------------------------------------------------------------
        private int CountUnvisited()
        {
            int count = 0;
            foreach (T coord in allMapCoords)
                if (!visited[coord]) count++;
            return count;
        }

        // -------------------------------------------------------------------
        // Remove the wall between two tiles, regardless of whether they are
        // spatial neighbors or linked via teleport.
        // Throws if they can't be connected at all.
        // -------------------------------------------------------------------
        private void RemoveWallBetween(T tileA, T tileB)
        {
            int idxAB = GetSpatialNeighborIndexOf(tileA, tileB);
            int idxBA = GetSpatialNeighborIndexOf(tileB, tileA);

            if (idxAB == -1 || idxBA == -1)
            {
                throw new System.InvalidOperationException(
                    $"Cannot remove wall: tiles [{tileA}] and [{tileB}] are not spatial neighbors. " +
                    "This may mean the topology requires a configuration that is not embeddable in 2D " +
                    "given the available grid size, or the junction tiles were placed too far apart.");
            }

            walls[tileA][idxAB] = false;
            walls[tileB][idxBA] = false;
        }
    }
}
