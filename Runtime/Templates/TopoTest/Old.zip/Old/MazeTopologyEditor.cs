#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

public class MazeTopologyEditor : EditorWindow
{
    private MazeTopologyAsset topology;
    private Vector2 scrollPosition;
    private MazeNodeData selectedNode;


    private const float NODE_WIDTH = 100f;
    private const float NODE_HEIGHT = 50f;

    [MenuItem("Assets/Open Maze Topology Editor")]
    public static void OpenFromAsset()
    {
        var topology = Selection.activeObject as MazeTopologyAsset;
        if (topology == null)
        {
            EditorUtility.DisplayDialog("Error", "Please select a MazeTopologyAsset", "OK");
            return;
        }

        var window = GetWindow<MazeTopologyEditor>("Maze Topology");
        window.SetTopology(topology);
    }

    [MenuItem("Window/Maze/Topology Editor")]
    public static void ShowWindow()
    {
        MazeTopologyEditor window = GetWindow<MazeTopologyEditor>("Maze Topology");
        var selectedAsset = Selection.activeObject as MazeTopologyAsset;
        if (selectedAsset != null && selectedAsset != window.topology)
        {
            window.SetTopology(selectedAsset);
        }

        if (window.topology == null)
        {
            EditorGUILayout.HelpBox("Select a MazeTopologyAsset to edit", MessageType.Info);
            return;
        }
        
    }

    public void SetTopology(MazeTopologyAsset newTopology)
    {
        topology = newTopology;
        Repaint();
    }

    private void OnGUI()
    {
        EditorGUILayout.BeginHorizontal();

        // Left panel: node/edge list
        EditorGUILayout.BeginVertical(GUILayout.Width(400));
        DrawNodeList();
        EditorGUILayout.Space();
        DrawEdgeList();
        EditorGUILayout.EndVertical();

        // Right panel: graph visual
        EditorGUILayout.BeginVertical();
        DrawGraphCanvas();
        EditorGUILayout.EndVertical();

        EditorGUILayout.EndHorizontal();
    }

    private bool connectedMode = false;
    private MazeNodeData connectionSource = null;


    private void DrawNodeList()
    {
        EditorGUILayout.LabelField("Nodes", EditorStyles.boldLabel);

        scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);

        if (topology?.nodes != null)
        {
            for (int i = 0; i < topology.nodes.Count; i++)
            {
                var node = topology.nodes[i];
                EditorGUILayout.BeginHorizontal();
                GUI.enabled = true;
                if (GUILayout.Button(node.name, GUILayout.Width(120)))
                {
                    if (changeSelectedEdgesNodeA && selectedEdgeIndex != -1)
                    {
                        selectedEdge.nodeAId = i;
                        changeSelectedEdgesNodeA = false;
                        GUI.enabled = false;
                    }
                    else if (changeSelectedEdgesNodeB && selectedEdgeIndex != -1)
                    {
                        selectedEdge.nodeBId = i;
                        changeSelectedEdgesNodeB = false;
                        GUI.enabled = false;
                    }
                    else
                    {
                        selectedNode = node;
                        DetectDoubleClick(node);
                    }
                }


                if (GUILayout.Button("X", GUILayout.Width(30)))
                    topology.nodes.RemoveAt(i);

                EditorGUILayout.EndHorizontal();
            }
        }

        EditorGUILayout.EndScrollView();

        EditorGUILayout.Space();

        if (GUILayout.Button("Add Node"))
        {
            var newNode = new MazeNodeData
            {
                id = topology.nodes.Count,
                name = $"Node_{topology.nodes.Count}",
                editorPosition = new Vector2(100, 100)
            };
            topology.nodes.Add(newNode);
        }
        GUI.enabled = true;
    }
    private MazeEdgeData selectedEdge
    {
        get
        {
            if (selectedEdgeIndex != -1)
                return topology.edges[selectedEdgeIndex];
            return null;
        }
    }
    private int selectedEdgeIndex=-1;
    bool changeSelectedEdgesNodeA = false;
    bool changeSelectedEdgesNodeB = false;
    private void DrawEdgeList()
    {
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("Edges", EditorStyles.boldLabel, GUILayout.Width(80));
        EditorGUILayout.LabelField("Node A", GUILayout.Width(120));
        EditorGUILayout.LabelField("Node B", GUILayout.Width(120));
        EditorGUILayout.LabelField("Remove", GUILayout.Width(30));
        EditorGUILayout.EndHorizontal();
        
        if (selectedEdge != null)
        {
            if (changeSelectedEdgesNodeA)
                EditorGUILayout.LabelField("Select a Node for Edge[] node A", EditorStyles.boldLabel);
            else if (changeSelectedEdgesNodeA)
                EditorGUILayout.LabelField("Select a Node for Edge[] node A", EditorStyles.boldLabel);
            else 
                EditorGUILayout.LabelField("Selected Edge[" + selectedEdgeIndex + "]");
        }

        scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);

        if (topology?.nodes != null)
        {
            for (int i = 0; i < topology.nodes.Count; i++)
            {
                var edge = topology.edges[i];
                if(selectedEdgeIndex==i)
                    EditorGUILayout.BeginHorizontal(EditorStyles.helpBox);
                else
                    EditorGUILayout.BeginHorizontal();

                var nodeA = topology.nodes[edge.nodeAId];
                var nodeB = topology.nodes[edge.nodeBId];
                EditorGUILayout.LabelField("Edge [" + i + "]", GUILayout.Width(80));

                if (changeSelectedEdgesNodeA|| changeSelectedEdgesNodeB)
                    GUI.enabled = false;

                if (GUILayout.Button( nodeA.name , GUILayout.Width(120)))
                {
                    changeSelectedEdgesNodeA = true;
                    changeSelectedEdgesNodeB = false;
                    selectedEdgeIndex = i;
                }


                if (GUILayout.Button(nodeB.name , GUILayout.Width(120)))
                {
                    changeSelectedEdgesNodeB = true;
                    changeSelectedEdgesNodeA = false;
                    selectedEdgeIndex = i;
                }

                if (GUILayout.Button("X", GUILayout.Width(30)))
                {
                    topology.nodes.RemoveAt(i);
                    selectedEdgeIndex = -1;
                }
                GUI.enabled = true;
                EditorGUILayout.EndHorizontal();
            }
        }

        EditorGUILayout.EndScrollView();

        EditorGUILayout.Space();

        if (GUILayout.Button("Add Edge"))
        {
            var newEdge = new MazeEdgeData
            {
                id = topology.edges.Count,
                isTeleport = false
            };
            topology.edges.Add(newEdge);
        }
    }
    private void DrawGraphCanvas()
    {
        EditorGUILayout.LabelField("Topology Graph", EditorStyles.boldLabel);

        Rect canvasRect = EditorGUILayout.GetControlRect(GUILayout.Width(600), GUILayout.Height(500));
        GUI.Box(canvasRect, "", EditorStyles.helpBox);

        // Handle events
        HandleCanvasEvents(canvasRect);

        if (topology?.nodes != null)
        {
            // Draw edges first (so they appear behind nodes)
            if (topology.edges != null)
            {
                foreach (var edge in topology.edges)
                {
                    var nodeA = topology.nodes.Find(n => n.id == edge.nodeAId);
                    var nodeB = topology.nodes.Find(n => n.id == edge.nodeBId);

                    if (nodeA != null && nodeB != null)
                    {
                        DrawEdge(canvasRect, nodeA, nodeB, edge);
                    }
                }
            }

            // Draw nodes
            for (int i = 0; i < topology.nodes.Count; i++)
            {
                DrawNode(canvasRect, topology.nodes[i], i);
            }
        }

        // Draw UI controls below canvas
        EditorGUILayout.Space();
        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("Add Node"))
        {
            var newNode = new MazeNodeData
            {
                id = topology.nodes.Count,
                name = $"Node_{topology.nodes.Count}",
                editorPosition = new Vector2(50 + topology.nodes.Count * 30, 50 + topology.nodes.Count * 30)
            };
            topology.nodes.Add(newNode);
            EditorUtility.SetDirty(topology);
        }
        if (connectedMode) 
            GUI.enabled = false;
        if (GUILayout.Button("Add Edge (from selected to...)"))
        {
            GUI.enabled = true;
            if (selectedNode == null)
            {
                EditorUtility.DisplayDialog("Error", "Select a source node first", "OK");
            }
            else
            {
                connectedMode = true;  // Enter connection mode
            }
        }
        GUI.enabled = true;
        EditorGUILayout.EndHorizontal();
    }

    private MazeNodeData draggingNode = null;
    private void OLDDrawNode(Rect canvasRect, MazeNodeData node, int index)
    {
        Rect nodeRect = new Rect(
            canvasRect.x + node.editorPosition.x,
            canvasRect.y + node.editorPosition.y,
            NODE_WIDTH,
            NODE_HEIGHT
        );

        // Handle dragging
        if (Event.current.type == EventType.MouseDown && nodeRect.Contains(Event.current.mousePosition))
        {
            draggingNode = node;
            //Event.current.Use();
        }

        if (draggingNode == node && Event.current.type == EventType.MouseDrag)
        {
            node.editorPosition += Event.current.delta;  // delta already has the movement
            GUI.changed = true;
            Event.current.Use();
        }

        if (Event.current.type == EventType.MouseUp)
        {
            draggingNode = null;
        }

        // Draw box
        Color color = (node == selectedNode) ? Color.green : Color.gray;
        if (node.isStart) color = Color.cyan;
        if (node.isEnd) color = Color.red;

        GUI.backgroundColor = color;
        if (GUI.Button(nodeRect, node.name,EditorStyles.helpBox))
        {
            if (!connectedMode)
            {
                selectedNode = node;
                connectionSource = node;
                DetectDoubleClick(node);
            }
            else
            {
                CreateEdge(connectionSource, node);
                connectedMode = false;
            }
        }

        GUI.backgroundColor = Color.white;
    }
    private const float EDGE_SPOT_RADIUS = 6f;
    private MazeEdgeData draggingEdgeSequence = null;
    private MazeNodeData draggingEdgeSequenceFrom = null;

    private void DrawNode(Rect canvasRect, MazeNodeData node, int index)
    {
        Rect nodeRect = new Rect(
            canvasRect.x + node.editorPosition.x,
            canvasRect.y + node.editorPosition.y,
            NODE_WIDTH,
            NODE_HEIGHT
        );

        // Handle dragging node itself
        if (Event.current.type == EventType.MouseDown && nodeRect.Contains(Event.current.mousePosition))
        {
            // Check if clicking on edge spots first
            bool clickedEdgeSpot = false;
            for (int i = 0; i < node.edgeSequence.Count; i++)
            {
                Rect spotRect = GetEdgeSpotRect(nodeRect, i, node.edgeSequence.Count);
                if (spotRect.Contains(Event.current.mousePosition))
                {
                    int edgeIndex = node.edgeSequence[i];
                    var edge = topology.edges[edgeIndex < 0 ? -(edgeIndex + 1) : edgeIndex];
                    draggingEdgeSequence = edge;
                    draggingEdgeSequenceFrom = node;
                    clickedEdgeSpot = true;
                    Event.current.Use();
                    break;
                }
            }

            if (!clickedEdgeSpot)
            {
                draggingNode = node;
            }
        }

        // Handle dragging edge sequence indicator
        if (draggingEdgeSequence != null && Event.current.type == EventType.MouseDrag)
        {
            // Find which position the mouse is closest to
            int closestPosition = 0;
            float closestDistance = float.MaxValue;

            for (int i = 0; i < draggingEdgeSequenceFrom.edgeSequence.Count; i++)
            {
                Rect spotRect = GetEdgeSpotRect(nodeRect, i, draggingEdgeSequenceFrom.edgeSequence.Count);
                float distance = Vector2.Distance(Event.current.mousePosition, spotRect.center);

                if (distance < closestDistance)
                {
                    closestDistance = distance;
                    closestPosition = i;
                }
            }

            // Reorder the edge in the sequence
            int currentPosition = draggingEdgeSequenceFrom.edgeSequence.FindIndex(ei =>
            {
                int idx = ei < 0 ? -(ei + 1) : ei;
                return topology.edges[idx] == draggingEdgeSequence;
            });

            if (currentPosition != closestPosition)
            {
                int edgeIndexValue = draggingEdgeSequenceFrom.edgeSequence[currentPosition];
                draggingEdgeSequenceFrom.edgeSequence.RemoveAt(currentPosition);
                draggingEdgeSequenceFrom.edgeSequence.Insert(closestPosition, edgeIndexValue);
                EditorUtility.SetDirty(topology);
            }

            GUI.changed = true;
            Event.current.Use();
        }

        if (Event.current.type == EventType.MouseUp)
        {
            draggingNode = null;
            draggingEdgeSequence = null;
            draggingEdgeSequenceFrom = null;
        }

        // Handle regular node dragging
        if (draggingNode == node && Event.current.type == EventType.MouseDrag && draggingEdgeSequence == null)
        {
            node.editorPosition += Event.current.delta;
            GUI.changed = true;
            Event.current.Use();
        }

        // Draw box
        Color color = (node == selectedNode) ? Color.green : Color.gray;
        if (node.isStart) color = Color.cyan;
        if (node.isEnd) color = Color.red;

        GUI.backgroundColor = color;
        if (GUI.Button(nodeRect, node.name, EditorStyles.helpBox))
        {
            if (!connectedMode)
            {
                selectedNode = node;
                connectionSource = node;
                DetectDoubleClick(node);
            }
            else
            {
                CreateEdge(connectionSource, node);
                connectedMode = false;
            }
        }

        GUI.backgroundColor = Color.white;

        // Draw edge sequence spots
        DrawEdgeSequenceSpots(nodeRect, node);
    }

    private void DrawEdgeSequenceSpots(Rect nodeRect, MazeNodeData node)
    {
        if (node.edgeSequence.Count == 0)
            return;

        for (int i = 0; i < node.edgeSequence.Count; i++)
        {
            Rect spotRect = GetEdgeSpotRect(nodeRect, i, node.edgeSequence.Count);

            // Highlight if dragging
            Color spotColor = Color.white;
            if (draggingEdgeSequence != null && draggingEdgeSequenceFrom == node)
            {
                int edgeIndex = node.edgeSequence[i];
                var edge = topology.edges[edgeIndex < 0 ? -(edgeIndex + 1) : edgeIndex];
                if (edge == draggingEdgeSequence)
                    spotColor = Color.yellow;
            }

            // Draw spot
            Handles.color = spotColor;
            Handles.DrawSolidDisc(spotRect.center, Vector3.forward, EDGE_SPOT_RADIUS);

            // Draw number
            GUI.color = Color.black;
            GUI.Label(spotRect, i.ToString(), new GUIStyle(EditorStyles.label)
            {
                alignment = TextAnchor.MiddleCenter,
                fontSize = 10
            });
            GUI.color = Color.white;
        }
    }

    private Rect GetEdgeSpotRect(Rect nodeRect, int position, int totalEdges)
    {
        // Distribute spots around the perimeter of the node
        float angle = (position / (float)totalEdges) * 360f * Mathf.Deg2Rad;

        float x = nodeRect.center.x + Mathf.Cos(angle) * (NODE_WIDTH / 2 + 15);
        float y = nodeRect.center.y + Mathf.Sin(angle) * (NODE_HEIGHT / 2 + 15);

        return new Rect(x - EDGE_SPOT_RADIUS, y - EDGE_SPOT_RADIUS, EDGE_SPOT_RADIUS * 2, EDGE_SPOT_RADIUS * 2);
    }

    private void DrawEdge(Rect canvasRect, MazeNodeData nodeA, MazeNodeData nodeB, MazeEdgeData edge)
    {
        Vector2 startPos = new Vector2(canvasRect.x + nodeA.editorPosition.x + NODE_WIDTH / 2,
                                       canvasRect.y + nodeA.editorPosition.y + NODE_HEIGHT / 2);
        Vector2 endPos = new Vector2(canvasRect.x + nodeB.editorPosition.x + NODE_WIDTH / 2,
                                     canvasRect.y + nodeB.editorPosition.y + NODE_HEIGHT / 2);

        // Move to edge of nodes instead of center
        Vector2 direction = (endPos - startPos).normalized;
        startPos += direction * (NODE_WIDTH / 2);
        endPos -= direction * (NODE_WIDTH / 2);

        // Create control points for curve (curve to the right)
        Vector2 perpendicular = new Vector2(-direction.y, direction.x);  // Perpendicular to direction
        float curveDistance = Vector2.Distance(startPos, endPos) * 0.2f;  // 20% of distance

        Vector2 controlA = startPos + perpendicular * curveDistance + direction * curveDistance;
        Vector2 controlB = endPos + perpendicular * curveDistance - direction * curveDistance;

        // Draw the curved line
        Color lineColor = Color.white;
        if (edge.isTeleport) lineColor = Color.cyan;
       // if (edge.isOneWayAtoB) lineColor = Color.yellow;

        Handles.color = lineColor;
        Handles.DrawBezier(startPos, endPos, controlA, controlB, lineColor, null, 2f);//, 24);

        // Draw arrowhead at end
        //direction = (endPos - startPos).normalized;
        float arrowSize = 10;
        Vector2 endDir = (endPos - controlB).normalized;
        Vector2 endDirPerp = new Vector2(-endDir.y, endDir.x);
        //Vector2 arrowStart = endPos - direction * arrowSize;
        Vector2 arrowStart = endPos - endDir * arrowSize;

        Vector2 arrowLeft = arrowStart + endDirPerp * arrowSize*0.5f;
        Vector2 arrowRight = arrowStart - endDirPerp * arrowSize * 0.5f;

        Handles.DrawLine(arrowLeft, endPos);
        Handles.DrawLine(arrowRight, endPos);
    }

    private void HandleCanvasEvents(Rect canvasRect)
    {
        if (Event.current.type == EventType.MouseMove)
            Repaint();
    }

    private void CreateEdge(MazeNodeData from, MazeNodeData to)
    {
        var edge = new MazeEdgeData
        {
            id = topology.edges.Count,
            nodeAId = from.id,
            nodeBId = to.id,
            isTeleport = false,
        };

        topology.edges.Add(edge);


        EditorUtility.SetDirty(topology);
    }

    private double lastClickTime = 0;
    private MazeNodeData lastClickedNode = null;
    private const double DOUBLE_CLICK_TIME = 0.3;  // 300ms

    private void ShowRenameDialog(MazeNodeData node)
    {
        var dialog = ScriptableObject.CreateInstance<RenameNodeDialog>();
        dialog.Initialize(node, topology);
        dialog.ShowModal();
    }

    private void DetectDoubleClick(MazeNodeData node)
    {
        double timeSinceLastClick = EditorApplication.timeSinceStartup - lastClickTime;

        if (lastClickedNode == node && timeSinceLastClick < DOUBLE_CLICK_TIME)
        {
            // Double click detected
            ShowRenameDialog(node);
            lastClickedNode = null;
            lastClickTime = 0;
        }
        else
        {
            lastClickedNode = node;
            lastClickTime = EditorApplication.timeSinceStartup;
        }
    }
}
#endif
