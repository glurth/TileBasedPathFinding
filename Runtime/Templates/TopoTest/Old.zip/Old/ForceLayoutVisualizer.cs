﻿using UnityEngine;
using System.Collections;

public class ForceLayoutVisualizer : MonoBehaviour
{
    MazeTopology maze;
    //private MazeTopology.ForceLayoutState state;
    private MazeTopology.EdgeForces state;

    private Material lineMaterial;

    public float linStr;
    public float rotStr;
    public float desiredCloseDistance;
    public float edgeRepelStrengthFactor;
    public float springLengthStrength;
    public float edgeNodeAntiParallelTorqueStength;

    void Start()
    {
        maze = ExampleTopologies.BuildSampleTopology();
        //state = maze.InitLayout();
        state = maze.InitEdgeLayout();
        OnValidate();
        /*linStr = state.strengthPer;
        rotStr = state.rotStrengthPer;
        edgeRepelStrengthFactor =state.edgeRepelStrengthFactor;
        desiredCloseDistance = state.desiredCloseDistance;*/
        CreateMaterial();
        StartCoroutine(RunLayout());
    }
    void OnValidate()
    {
        if (state == null) return;
        state.strengthPer= linStr;
        state.rotStrengthPer= rotStr;
        state.desiredCloseDistance= desiredCloseDistance;
        state.edgeRepelStrengthFactor= edgeRepelStrengthFactor;
        state.springLengthStrength= springLengthStrength;
        state.edgeNodeAntiParallelTorqueStength= edgeNodeAntiParallelTorqueStength;
}


    IEnumerator RunLayout()
    {
        while (true)
        {
            maze.StepLayout(state);
            yield return null; // 1 step per frame
        }
    }

    void CreateMaterial()
    {
        Shader shader = Shader.Find("Hidden/Internal-Colored");
        lineMaterial = new Material(shader);
    }
    Color edgeColor = Color.green;
    Color teleportEdgeColor = Color.grey;
    Color nodeColor = Color.blue;
    Color fixedNodeColor = Color.black;
    void OnRenderObject()
    {
        if (state == null) return;

        lineMaterial.SetPass(0);

        GL.PushMatrix();
        // GL.LoadOrtho();
        GL.LoadIdentity();
        float margin = 0.1f;

        Matrix4x4 m = Matrix4x4.Ortho(
            0.0f - margin, 1.0f + margin,
            0.0f - margin, 1.0f + margin,
            -1.0f, 1.0f
        );

        GL.LoadProjectionMatrix(m);

        // draw edges
        GL.Begin(GL.LINES);

        for (int i = 0; i < maze.mazeEdges.Count; i++)
        {
            MazeEdge edge = maze.mazeEdges[i];
            
            if (edge.isTeleport)
                GL.Color(teleportEdgeColor);
            else
                GL.Color(edgeColor);
            int a = maze.mazeNodes.IndexOf(edge.nodeA);
            int b = maze.mazeNodes.IndexOf(edge.nodeB);


            Vector2 pa = GetNodeEdgePosition(a, edge.nodeA.edgeSequence.IndexOf(i));// state.positionsByNode[a]+ GetEdgeRadialOffset(edge.nodeA,a, edge);
            Vector2 pb = GetNodeEdgePosition(b, edge.nodeB.edgeSequence.IndexOf(i));// state.positionsByNode[b]+ GetEdgeRadialOffset(edge.nodeB,b, edge);


            GL.Vertex(new Vector3(pa.x, pa.y, 0));
            GL.Vertex(new Vector3(pb.x, pb.y, 0));
        }
        GL.End();

        // draw nodes
        //GL.Begin(GL.QUADS);
        GL.Begin(GL.LINES);
        float size = 0.01f;
        
        for (int i = 0; i < state.count; i++)
        {
            Vector2 p = state.nodePosition[i];// state.positionsByNode[i];
            if (state.fixedNodes.Contains(i))
                GL.Color(fixedNodeColor);
            else
                GL.Color(nodeColor);
            MazeNode node = maze.mazeNodes[i];
            for (int j = 0; j < node.edgeSequence.Count; j++)
            {
                Vector2 edgePos = GetNodeEdgePosition(i, j);
                GL.Vertex(new Vector3(p.x, p.y, 0));
                GL.Vertex(new Vector3(edgePos.x, edgePos.y, 0));
            }
        }

        GL.End();

        GL.PopMatrix();
    }

    int GetEdgeIndex(MazeNode node, MazeEdge edge)
    {
        foreach (int edgeIndex in node.edgeSequence)
        {
            if (maze.mazeEdges[edgeIndex] == edge)
                return edgeIndex;
        }
        return -1;
    }
    float offsetMagnitude=0.03f;
    /*Vector2 GetEdgeRadialOffset(MazeNode node,int nodeIndex, MazeEdge edge)
    {
        return maze.GetEdgeOffset(state, node, nodeIndex, edge, offsetMagnitude);
    }*/
    Vector2 GetNodeEdgePosition(int nodeIndex, int edgeIndex)
    {
        return state.nodePosition[nodeIndex] + Rotate(state.offsetsOfNodeEdgesByNodeIndex[nodeIndex][edgeIndex], state.nodeAngle[nodeIndex]);
    }
    public static Vector2 Rotate(Vector2 v, float angleRad)
    {
        float cos = Mathf.Cos(angleRad);
        float sin = Mathf.Sin(angleRad);

        float x = v.x * cos - v.y * sin;
        float y = v.x * sin + v.y * cos;

        return new Vector2(x, y);
    }
}